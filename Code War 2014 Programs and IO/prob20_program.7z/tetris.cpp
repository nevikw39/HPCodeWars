#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int mResult = 0;
int order[6];

struct point{
  int x;
  int y;     
};

struct table {
  int matrix[6][6];     
};

struct point I_tetris_1[4];
struct point I_tetris_2[4];
struct point o_tetris_1[4];
struct point j_tetris_1[4];
struct point j_tetris_2[4];
struct point j_tetris_3[4];
struct point j_tetris_4[4];
struct point t_tetris_1[4];
struct point t_tetris_2[4];
struct point t_tetris_3[4];
struct point t_tetris_4[4];
struct point l_tetris_1[4];
struct point l_tetris_2[4];
struct point l_tetris_3[4];
struct point l_tetris_4[4];
struct point s_tetris_1[4];
struct point s_tetris_2[4];
struct point z_tetris_1[4];
struct point z_tetris_2[4];


bool initial () {
     //memset(matrix, 0, sizeof(matrix));
     I_tetris_1[0].x = 0; I_tetris_1[0].y = 0; //**** case1
     I_tetris_1[1].x = 0; I_tetris_1[1].y = 1;
     I_tetris_1[2].x = 0; I_tetris_1[2].y = 2;
     I_tetris_1[3].x = 0; I_tetris_1[3].y = 3;
     
     I_tetris_2[0].x = 0; I_tetris_2[0].y = 0; //*    case2
     I_tetris_2[1].x = 1; I_tetris_2[1].y = 0; //*
     I_tetris_2[2].x = 2; I_tetris_2[2].y = 0; //*
     I_tetris_2[3].x = 3; I_tetris_2[3].y = 0; //*
     
     o_tetris_1[0].x = 0; o_tetris_1[0].y = 0; //**   case3
     o_tetris_1[1].x = 0; o_tetris_1[1].y = 1; //**
     o_tetris_1[2].x = 1; o_tetris_1[2].y = 0;
     o_tetris_1[3].x = 1; o_tetris_1[3].y = 1;
     
     j_tetris_1[0].x = 0; j_tetris_1[0].y = 0; //***  case4
     j_tetris_1[1].x = 0; j_tetris_1[1].y = 1; //  *
     j_tetris_1[2].x = 0; j_tetris_1[2].y = 2;
     j_tetris_1[3].x = 1; j_tetris_1[3].y = 2;
     
     j_tetris_2[0].x = 0; j_tetris_2[0].y = 1; // *  case5
     j_tetris_2[1].x = 1; j_tetris_2[1].y = 1; // *
     j_tetris_2[2].x = 2; j_tetris_2[2].y = 0; //**
     j_tetris_2[3].x = 2; j_tetris_2[3].y = 1;
     
     j_tetris_3[0].x = 0; j_tetris_3[0].y = 0; //*  case6
     j_tetris_3[1].x = 1; j_tetris_3[1].y = 0; //***
     j_tetris_3[2].x = 1; j_tetris_3[2].y = 1; //
     j_tetris_3[3].x = 1; j_tetris_3[3].y = 2;
     
     j_tetris_4[0].x = 0; j_tetris_4[0].y = 0; //** case7
     j_tetris_4[1].x = 0; j_tetris_4[1].y = 1; //*
     j_tetris_4[2].x = 1; j_tetris_4[2].y = 0; //*
     j_tetris_4[3].x = 2; j_tetris_4[3].y = 0;
     
     t_tetris_1[0].x = 0; t_tetris_1[0].y = 1; // *  case8
     t_tetris_1[1].x = 1; t_tetris_1[1].y = 0; //***
     t_tetris_1[2].x = 1; t_tetris_1[2].y = 1;
     t_tetris_1[3].x = 1; t_tetris_1[3].y = 2;
     
     t_tetris_2[0].x = 0; t_tetris_2[0].y = 1; // *  case9
     t_tetris_2[1].x = 1; t_tetris_2[1].y = 0; //**
     t_tetris_2[2].x = 1; t_tetris_2[2].y = 1; // *
     t_tetris_2[3].x = 2; t_tetris_2[3].y = 1;
     
     t_tetris_3[0].x = 0; t_tetris_3[0].y = 0; //***  case10
     t_tetris_3[1].x = 0; t_tetris_3[1].y = 1; // *
     t_tetris_3[2].x = 0; t_tetris_3[2].y = 2; //
     t_tetris_3[3].x = 1; t_tetris_3[3].y = 1;
     
     t_tetris_4[0].x = 0; t_tetris_4[0].y = 0; //*  case11
     t_tetris_4[1].x = 1; t_tetris_4[1].y = 0; //**
     t_tetris_4[2].x = 2; t_tetris_4[2].y = 0; //*
     t_tetris_4[3].x = 1; t_tetris_4[3].y = 1;
     
     l_tetris_1[0].x = 0; l_tetris_1[0].y = 0; //*   case12
     l_tetris_1[1].x = 1; l_tetris_1[1].y = 0; //*
     l_tetris_1[2].x = 2; l_tetris_1[2].y = 0; //**
     l_tetris_1[3].x = 2; l_tetris_1[3].y = 1;
     
     l_tetris_2[0].x = 0; l_tetris_2[0].y = 0; //***  case13
     l_tetris_2[1].x = 0; l_tetris_2[1].y = 1; //*
     l_tetris_2[2].x = 0; l_tetris_2[2].y = 2; // 
     l_tetris_2[3].x = 1; l_tetris_2[3].y = 0;
     
     l_tetris_3[0].x = 0; l_tetris_3[0].y = 0; //**  case14
     l_tetris_3[1].x = 0; l_tetris_3[1].y = 1; // *
     l_tetris_3[2].x = 1; l_tetris_3[2].y = 1; // *
     l_tetris_3[3].x = 2; l_tetris_3[3].y = 1;
     
     l_tetris_4[0].x = 0; l_tetris_4[0].y = 2; //  * case15
     l_tetris_4[1].x = 1; l_tetris_4[1].y = 0; //***
     l_tetris_4[2].x = 1; l_tetris_4[2].y = 1; //
     l_tetris_4[3].x = 1; l_tetris_4[3].y = 2;
     
     //
     s_tetris_1[0].x = 0; s_tetris_1[0].y = 1; // ** case16
     s_tetris_1[1].x = 0; s_tetris_1[1].y = 2; //**
     s_tetris_1[2].x = 1; s_tetris_1[2].y = 0; //
     s_tetris_1[3].x = 1; s_tetris_1[3].y = 1;
     
     s_tetris_2[0].x = 0; s_tetris_2[0].y = 0; //*  case17
     s_tetris_2[1].x = 1; s_tetris_2[1].y = 0; //**
     s_tetris_2[2].x = 1; s_tetris_2[2].y = 1; // *
     s_tetris_2[3].x = 2; s_tetris_2[3].y = 1;
     
     z_tetris_1[0].x = 0; z_tetris_1[0].y = 0; //**  case18
     z_tetris_1[1].x = 0; z_tetris_1[1].y = 1; // **
     z_tetris_1[2].x = 1; z_tetris_1[2].y = 1; // 
     z_tetris_1[3].x = 1; z_tetris_1[3].y = 2;
     
     z_tetris_2[0].x = 0; z_tetris_2[0].y = 1; // * case19
     z_tetris_2[1].x = 1; z_tetris_2[1].y = 0; //**
     z_tetris_2[2].x = 1; z_tetris_2[2].y = 1; //*
     z_tetris_2[3].x = 2; z_tetris_2[3].y = 0;
     
     //
     return true;
}

bool printmatrix (struct table *temp) {
     for (int i=0; i<6; i++) {
      for (int j=0; j<6; j++) {
          if (temp->matrix[i][j] != 0) {
             //printf("%d",temp->matrix[i][j]);                  
          } else {
             //printf("_");           
          }   
      }
      //printf("\n");
     }
     
  return true;   
}

bool check (int i, int j, int level, struct table *sample) {

        struct table temp;   
        memcpy(&temp,sample,sizeof(struct table));

        switch (order[level]) {
               case 1:
                    if (j+3 < 6) {
                       //printf("case: 1\n");
                       for (int k=0;k<4;k++) {
                           if (temp.matrix[i+I_tetris_1[k].x][j+I_tetris_1[k].y] != 0) {
                              return false;                                                      
                           }
                           temp.matrix[i+I_tetris_1[k].x][j+I_tetris_1[k].y] = level+1;
                       }
                            
                    } else {
                       return false;       
                    }
                    break;
               case 2:
                    if (i+3 < 6) {
                       //printf("case: 2\n");     
                       for (int k=0;k<4;k++) {
                           if (temp.matrix[i+I_tetris_2[k].x][j+I_tetris_2[k].y] != 0) {
                              return false;                                                      
                           }
                           temp.matrix[i+I_tetris_2[k].x][j+I_tetris_2[k].y] = level+1;
                       }
                            
                    } else {
                        return false;
                    }
                    break;
               case 3:
                    if ((i+1 < 6) && (j+1 < 6)) {
                       for (int k=0;k<4;k++) {
                           if (temp.matrix[i+o_tetris_1[k].x][j+o_tetris_1[k].y] != 0) {
                              return false;                                                      
                           }
                           temp.matrix[i+o_tetris_1[k].x][j+o_tetris_1[k].y] = level+1;
                       }
                             
                    } else {
                        return false;
                    }
                    break;
               case 4:
                    if ((i+1 < 6) && (j+2) <6) {
                       for (int k=0;k<4;k++) {
                           if (temp.matrix[i+j_tetris_1[k].x][j+j_tetris_1[k].y] != 0) {
                              return false;                                                      
                           }
                           temp.matrix[i+j_tetris_1[k].x][j+j_tetris_1[k].y] = level+1;
                       }
                             
                    } else {
                        return false;
                    }
                    break;
               case 5:
                    if ((i+2 < 6) && (j+1) <6) {
                       for (int k=0;k<4;k++) {
                           if (temp.matrix[i+j_tetris_2[k].x][j+j_tetris_2[k].y] != 0) {
                              return false;                                                      
                           }
                           temp.matrix[i+j_tetris_2[k].x][j+j_tetris_2[k].y] = level+1;
                       }
                             
                    } else {
                        return false;
                    }
                    break;
               case 6:
                    if ((i+1 < 6) && (j+2) <6) {
                       for (int k=0;k<4;k++) {
                           if (temp.matrix[i+j_tetris_3[k].x][j+j_tetris_3[k].y] != 0) {
                              return false;                                                      
                           }
                           temp.matrix[i+j_tetris_3[k].x][j+j_tetris_3[k].y] = level+1;
                       }
                           
                    } else {
                        return false;
                    }
                    break;
               case 7:
                    if ((i+2 < 6) && (j+1) <6) {
                       for (int k=0;k<4;k++) {
                           if (temp.matrix[i+j_tetris_4[k].x][j+j_tetris_4[k].y] != 0) {
                              return false;                                                      
                           }
                           temp.matrix[i+j_tetris_4[k].x][j+j_tetris_4[k].y] = level+1;
                       }
                            
                    } else {
                        return false;
                    }
                    break;
               case 8:
                    if ((i+1 < 6) && (j+2) <6) {
                       for (int k=0;k<4;k++) {
                           if (temp.matrix[i+t_tetris_1[k].x][j+t_tetris_1[k].y] != 0) {
                              return false;                                                      
                           }
                           temp.matrix[i+t_tetris_1[k].x][j+t_tetris_1[k].y] = level+1;
                       }
                             
                    } else {
                        return false;
                    }
                    break;
               case 9:
                    if ((i+2 < 6) && (j+1) <6) {
                       for (int k=0;k<4;k++) {
                           if (temp.matrix[i+t_tetris_2[k].x][j+t_tetris_2[k].y] != 0) {
                              return false;                                                      
                           }
                           temp.matrix[i+t_tetris_2[k].x][j+t_tetris_2[k].y] = level+1;
                       }
                             
                    } else {
                        return false;
                        }
                    break;
               case 10:
                    if ((i+1 < 6) && (j+2) <6) {
                       for (int k=0;k<4;k++) {
                           if (temp.matrix[i+t_tetris_3[k].x][j+t_tetris_3[k].y] != 0) {
                              return false;                                                      
                           }
                           temp.matrix[i+t_tetris_3[k].x][j+t_tetris_3[k].y] = level+1;
                       }
                            
                    } else {
                        return false;
                        }
                    break;
               case 11://T4
                    if ((i+2 < 6) && (j+1) <6) {
                       for (int k=0;k<4;k++) {
                           if (temp.matrix[i+t_tetris_4[k].x][j+t_tetris_4[k].y] != 0) {
                              return false;                                                      
                           }
                           temp.matrix[i+t_tetris_4[k].x][j+t_tetris_4[k].y] = level+1;
                       }
                             
                    } else {
                        return false;
                        }
                    break;
               case 12:
                    if ((i+2 < 6) && (j+1) <6) {
                       for (int k=0;k<4;k++) {
                           if (temp.matrix[i+l_tetris_1[k].x][j+l_tetris_1[k].y] != 0) {
                              return false;                                                      
                           }
                           temp.matrix[i+l_tetris_1[k].x][j+l_tetris_1[k].y] = level+1;
                       }
                             
                    } else {
                        return false;
                    }
                    break;
               case 13:
                    if ((i+1 < 6) && (j+2) <6) {
                       for (int k=0;k<4;k++) {
                           if (temp.matrix[i+l_tetris_2[k].x][j+l_tetris_2[k].y] != 0) {
                              return false;                                                      
                           }
                           temp.matrix[i+l_tetris_2[k].x][j+l_tetris_2[k].y] = level+1;
                       }
                             
                    } else {
                        return false;
                        }
                    break;
               case 14:
                    if ((i+2 < 6) && (j+1) <6) {
                       for (int k=0;k<4;k++) {
                           if (temp.matrix[i+l_tetris_3[k].x][j+l_tetris_3[k].y] != 0) {
                              return false;                                                      
                           }
                           temp.matrix[i+l_tetris_3[k].x][j+l_tetris_3[k].y] = level+1;
                       }
                            
                    } else {
                        return false;
                        }
                    break;
               case 15://L4
                    if ((i+1 < 6) && (j+2) <6) {
                       for (int k=0;k<4;k++) {
                           if (temp.matrix[i+l_tetris_4[k].x][j+l_tetris_4[k].y] != 0) {
                              return false;                                                      
                           }
                           temp.matrix[i+l_tetris_4[k].x][j+l_tetris_4[k].y] = level+1;
                       }
                            
                    } else {
                        return false;
                        }
                    break;
               case 16:
                    if ((i+1 < 6) && (j+2) <6) {
                       for (int k=0;k<4;k++) {
                           if (temp.matrix[i+s_tetris_1[k].x][j+s_tetris_1[k].y] != 0) {
                              return false;                                                      
                           }
                           temp.matrix[i+s_tetris_1[k].x][j+s_tetris_1[k].y] = level+1;
                       }
                             
                    } else {
                        return false;
                        }
                    break;
               case 17:
                    if ((i+2 < 6) && (j+1) <6) {
                       for (int k=0;k<4;k++) {
                           if (temp.matrix[i+s_tetris_2[k].x][j+s_tetris_2[k].y] != 0) {
                              return false;                                                      
                           }
                           temp.matrix[i+s_tetris_2[k].x][j+s_tetris_2[k].y] = level+1;
                       }
                            
                    } else {
                        return false;
                        }
                    break;
               case 18:
                    if ((i+1 < 6) && (j+2) <6) {
                       for (int k=0;k<4;k++) {
                           if (temp.matrix[i+z_tetris_1[k].x][j+z_tetris_1[k].y] != 0) {
                              return false;                                                      
                           }
                           temp.matrix[i+z_tetris_1[k].x][j+z_tetris_1[k].y] = level+1;
                       }
                           
                    } else {
                        return false;
                        }
                    break;
               case 19:
                    if ((i+2 < 6) && (j+1) <6) {
                       for (int k=0;k<4;k++) {
                           if (temp.matrix[i+z_tetris_2[k].x][j+z_tetris_2[k].y] != 0) {
                              return false;                                                      
                           }
                           temp.matrix[i+z_tetris_2[k].x][j+z_tetris_2[k].y] = level+1;
                       }
                           
                    } else {
                        return false;
                        }
                    break;
                default:
                        return false;
                    break;       
        }
    

        //printf("do the memcpy...\n");
        memcpy(sample,&temp,sizeof(struct table));
        return true;    
}

//
//bool run_i_tetris (){
//
//     for (int i=0; i<6; i++) {
//         for (int j=0;j<6;j++) {
//             if(check(i,j,16)) {
//               system("CLS");
//               printmatrix();    
//               system("pause");               
//             }
//             if(check(i,j,17)) {
//               system("CLS");
//               printmatrix();    
//               system("pause");               
//             }
//             if(check(i,j,18)) {
//               system("CLS");
//               printmatrix();    
//               system("pause");               
//             }
//             if(check(i,j,19)) {
//               system("CLS");
//               printmatrix();    
//               system("pause");               
//             }
//
//         }
//     }
//     
//     return true;     
//}
int calculate_result (struct table *input) {
    
    int count = 0;
    bool flag = false;
    
    for (int i=0; i< 6; i++) {
        flag = false;
        for (int j=0; j<6; j++) {
            if (j==0 && (input->matrix[i][j] != 0)) {
               flag = true;      
            } 
            if (j != 0 && (input->matrix[i][j] == 0)) {
             flag = false;      
            }
        }    
        if (flag == true) {
           count++;
        }
    }
    
    return count;
    
}

bool doit(int level, struct table *sample) {
     if (level >= 6) {
        return false;
     }
     bool stop = true;
     
     struct table temp;
     
     
     for (int i=0;i<6;i++) {
         for(int j=0;j<6;j++) {
             memcpy(&temp,sample,sizeof(struct table));
             //system("CLS");
             //printf("base sample:\n");
             //printmatrix(sample);
             stop = true;
             //printf("check: i=%d, j=%d\n",i,j);
             stop = check(i,j,level,&temp);  
             //printmatrix(&temp);
             //printf("order:%d, type:%d\n",level,order[level]);
             if (stop) {
                int result = 0;       
                result = calculate_result (&temp);
                if (result == 2) {
                  //printf("score! %d points!\n", result);         
                  //printmatrix(&temp);
                  //system("pause");      
                }
                if (result > mResult){
                   mResult = result;           
                }
                //printf("highest_score:%d\n",mResult);
                //system("pause"); 
             }
             else {
                  continue;     
             }
             if ((level+1) < 6 && order[level+1]!=0) {
                doit((level+1),&temp);              
             }
         }    
     }
     return true;
     
}

void parse (char *input, int level) {
     if (strlen(input) == level){
       for (int i=0;i<6;i++){
           //printf("%d, ", order[i]);    
       }
       //printf("\n ready to DOIT, current score: %d\n", mResult);
       //system("pause");
       struct table start;
       memset(&start, 0, sizeof(start));
       doit(0,&start);
       return;                
     }
     else if (level < strlen(input)) {
          switch (input[level]) {
                 case 'I':
                      //printf("I1 ");
                      order[level] = 1;
                      parse(input, level+1);
                      //printf("I2 ");
                      order[level] = 2;
                      parse(input, level+1);
                      order[level] = 0;
                      break;
                      
                 case 'J':
                      //printf("J4 ");
                      order[level] = 4;
                      parse(input, level+1);
                      //printf("J5 ");
                      order[level] = 5;
                      parse(input, level+1);
                      //printf("J6 ");
                      order[level] = 6;
                      parse(input, level+1);
                      //printf("J7 ");
                      order[level] = 7;
                      parse(input, level+1);
                      order[level] = 0;
                      break;
                      
                 case 'L':
                      //printf("L12 ");
                      order[level] = 12;
                      parse(input, level+1);
                      //printf("L13 ");
                      order[level] = 13;
                      parse(input, level+1);
                      //printf("L14 ");
                      order[level] = 14;
                      parse(input, level+1);
                      //printf("L15 ");
                      order[level] = 15;
                      parse(input, level+1);
                      order[level] = 0;
                      break;
                      
                 case 'O':
                      //printf("O3 ");
                      order[level] = 3;
                      parse(input, level+1);
                      order[level] = 0;
                      break;
                      
                 case 'S':
                      //printf("S16 ");
                      order[level] = 16;
                      parse(input, level+1);
                      //printf("S17 ");
                      order[level] = 17;
                      parse(input, level+1);
                      //printf("S18 ");
                      order[level] = 18;
                      parse(input, level+1);
                      //printf("S19 ");
                      order[level] = 19;
                      parse(input, level+1);
                      order[level] = 0;
                      break;
                      
                 case 'T':
                      //printf("T8 ");
                      order[level] = 8;
                      parse(input, level+1);
                      //printf("T9 ");
                      order[level] = 9;
                      parse(input, level+1);
                      //printf("T10 ");
                      order[level] = 10;
                      parse(input, level+1);
                      //printf("T11 ");
                      order[level] = 11;
                      parse(input, level+1);
                      order[level] = 0;
                      break;
                      
                 case 'Z':
                      //printf("Z18 ");
                      order[level] = 18;
                      parse(input, level+1);
                      //printf("Z19 ");
                      order[level] = 19;
                      parse(input, level+1);
                      order[level] = 0;
                      break;
                      
                 default:
                       //printf("Warning: this input file contains unwanted character\n[including line-feed, carage returns]...\n\n");
                       //system("pause");
                       input[level] = 0;
                       break;
                 
          }
     }
     
}

int main () {
 
 
 initial ();   
    
 char in[10];
 fgets (in, 10, stdin);

 //fgets (in, 10, file);
 //printf ("get: %s\n", in);
 parse (in, 0);
 
 printf("%d", mResult);
 //system("pause");

  return 0;
}


