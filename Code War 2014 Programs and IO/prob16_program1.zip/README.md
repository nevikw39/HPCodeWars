# Game of Life

Game of Life implementation for HP CodeWars 2014.

## Execute

`main.py` takes arguments from stdin:

    $ echo "4 2 01111110 1" > prog.txt
    $ python main.py < prog.txt
    4 4 0010100110010100

Or:

    $ echo "4 2 01111110 1" | python main.py
    4 4 0010100110010100
    $ echo "4 2 01111110 2" | python main.py
    4 2 01111110

## Unit test

    $ pip install -r dev-requirements.txt
    $ nosetests --with-coverage
