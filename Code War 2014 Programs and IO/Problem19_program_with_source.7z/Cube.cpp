// Cube.cpp : Defines the entry point for the console application.
//

//#include "stdafx.h"
#include "iostream"

using namespace std;

#if 1
char defaultcube[6][3][3] = {{{'G','G','G'},{'G','G','G'},{'G','G','G'}},
						     {{'B','B','B'},{'B','B','B'},{'B','B','B'}},
						     {{'O','O','O'},{'O','O','O'},{'O','O','O'}},
						     {{'R','R','R'},{'R','R','R'},{'R','R','R'}},
						     {{'W','W','W'},{'W','W','W'},{'W','W','W'}},
							 {{'Y','Y','Y'},{'Y','Y','Y'},{'Y','Y','Y'}}};

#else
char defaultcube[6][3][3] = {{{'S','G','G'},{'G','G','G'},{'G','G','G'}},
							 {{'S','B','B'},{'B','B','B'},{'B','B','B'}},
						     {{'S','O','O'},{'O','O','O'},{'O','O','O'}},
						     {{'S','R','R'},{'R','R','R'},{'R','R','R'}},
						     {{'S','W','W'},{'W','W','W'},{'W','W','W'}},
						     {{'S','Y','Y'},{'Y','Y','Y'},{'Y','Y','Y'}}}; 
#endif

enum Face{
	F,
	B,
	L,
	R,
	U,
	D};

char templine[80];

class FACE 
{
private:
	char unit[3][3];

public:
	void setface(char* x){
		memcpy(unit, x, sizeof(unit));}
	
	char* getfacePoint(){
		return &unit[0][0];}

	char getunit(int x, int y){
		return unit[x][y];}

	void set1stRow(char* x){
		memcpy(unit, x, 3);}

	void turnR()	//������90��
	{
		char Tempface[3][3];

		memcpy(Tempface, unit, sizeof(unit));
		unit[0][2] = Tempface[0][0];
		unit[1][2] = Tempface[0][1];
		unit[2][2] = Tempface[0][2];
		unit[0][1] = Tempface[1][0];
//		unit[1][1] = Tempface[1][1];
		unit[2][1] = Tempface[1][2];
		unit[0][0] = Tempface[2][0];
		unit[1][0] = Tempface[2][1];
		unit[2][0] = Tempface[2][2];
	}
	
	void turnUD()    //������180��
	{
		char Tempface[3][3];

		memcpy(Tempface, unit, sizeof(unit));
		unit[0][0] = Tempface[2][2];
		unit[0][1] = Tempface[2][1];
		unit[0][2] = Tempface[2][0];
		unit[1][0] = Tempface[1][2];
//		unit[1][1] = Tempface[1][1];
		unit[1][2] = Tempface[1][0];
		unit[2][0] = Tempface[0][2];
		unit[2][1] = Tempface[0][1];
		unit[2][2] = Tempface[0][0];
	}

	void turnL()	//������270��
	{
		char Tempface[3][3];

		memcpy(Tempface, unit, sizeof(unit));
		unit[0][0] = Tempface[0][2];
		unit[0][1] = Tempface[1][2];
		unit[0][2] = Tempface[2][2];
		unit[1][0] = Tempface[0][1];
//		unit[1][1] = Tempface[1][1];
		unit[1][2] = Tempface[2][1];
		unit[2][0] = Tempface[0][0];
		unit[2][1] = Tempface[1][0];
		unit[2][2] = Tempface[2][0];
	}

};

class CUBE {
private:
	FACE face[6];
	char TempRow[3];

public:
	CUBE()
	{
		face[F].setface(&defaultcube[F][0][0]);
		face[B].setface(&defaultcube[B][0][0]);
		face[L].setface(&defaultcube[L][0][0]);
		face[R].setface(&defaultcube[R][0][0]);
		face[U].setface(&defaultcube[U][0][0]);
		face[D].setface(&defaultcube[D][0][0]);
	}

	void TurnRx()	// x
	{
		char Tempface[3][3];
		memcpy(Tempface, face[F].getfacePoint(), sizeof(Tempface));
		
		face[F].setface(face[D].getfacePoint());
		face[B].turnUD();
		face[D].setface(face[B].getfacePoint());
		face[U].turnUD();
		face[B].setface(face[U].getfacePoint());
		face[U].setface(&Tempface[0][0]);
		
		face[R].turnR();
		face[L].turnL();
	}

	void TurnUy()	// y
	{
		char Tempface[3][3];
		memcpy(Tempface, face[F].getfacePoint(), sizeof(Tempface));
		
		face[F].setface(face[R].getfacePoint());
		face[R].setface(face[B].getfacePoint());
		face[B].setface(face[L].getfacePoint());
		face[L].setface(&Tempface[0][0]);
		
		face[U].turnR();
		face[D].turnL();
	}

	void TurnFz()	// x
	{
		char Tempface[3][3];
		face[U].turnR();
		memcpy(Tempface, face[U].getfacePoint(), sizeof(Tempface));

		face[L].turnR();
		face[U].setface(face[L].getfacePoint());
		face[D].turnR();
		face[L].setface(face[D].getfacePoint());
		face[R].turnR();
		face[D].setface(face[R].getfacePoint());
		face[R].setface(&Tempface[0][0]);
		
		face[F].turnR();
		face[B].turnL();
	}

	void Clockwise(Face x)
	{
		char Temp[3];

		switch(x)
		{
		case R:
			TurnFz();
			TurnFz();
		case L:
			TurnFz();
			break;
		case B:
			TurnRx();
		case D:
			TurnRx();
		case F:
			TurnRx();
		case U:
		default:
			break;
		}

		face[U].turnR();
		memcpy(Temp, face[F].getfacePoint(), sizeof(Temp));

		face[F].set1stRow(face[R].getfacePoint());
		face[R].set1stRow(face[B].getfacePoint());
		face[B].set1stRow(face[L].getfacePoint());
		face[L].set1stRow(&Temp[0]);

		switch(x)
		{
		case L:
			TurnFz();
			TurnFz();
		case R:
			TurnFz();
			break;
		case F:
			TurnRx();
		case D:
			TurnRx();
		case B:
			TurnRx();
		case U:
		default:
			break;
		}
	}

	void getline(int line)
	{
		sprintf(templine, "%c%c%c\t%c%c%c\t%c%c%c\t%c%c%c\t%c%c%c\t%c%c%c", face[F].getunit(line, 0), face[F].getunit(line, 1), face[F].getunit(line, 2),
																			face[B].getunit(line, 0), face[B].getunit(line, 1), face[B].getunit(line, 2),
																			face[L].getunit(line, 0), face[L].getunit(line, 1), face[L].getunit(line, 2),
																			face[R].getunit(line, 0), face[R].getunit(line, 1), face[R].getunit(line, 2),
																			face[U].getunit(line, 0), face[U].getunit(line, 1), face[U].getunit(line, 2),
																			face[D].getunit(line, 0), face[D].getunit(line, 1), face[D].getunit(line, 2));
	}
};

int main()
{
	char buf[80];
	char check;
	int loop;
	int Buffer_Index=0;
	CUBE* cubeX = new CUBE();

	cin >> buf;

	while(buf[Buffer_Index]!=0)
	{
		check = buf[Buffer_Index];
		Buffer_Index++;
		if (buf[Buffer_Index]=='2')
		{
			loop = 2;
			Buffer_Index++;
		}
		else if (buf[Buffer_Index]=='i')
		{
			loop = 3;
			Buffer_Index++;
		}
		else
			loop = 1;

		for (int i=0;i<loop;i++)
		{
			switch(check)
			{
			case 'F':
				cubeX->Clockwise(F);
				break;
			case 'B':
				cubeX->Clockwise(B);
				break;
			case 'L':
				cubeX->Clockwise(L);
				break;
			case 'R':
				cubeX->Clockwise(R);
				break;
			case 'U':
				cubeX->Clockwise(U);
				break;
			case 'D':
				cubeX->Clockwise(D);
				break;
				
			case 'f':
				cubeX->Clockwise(B);
				cubeX->TurnFz();
				break;

			case 'b':
				cubeX->Clockwise(F);
				cubeX->TurnFz();
				cubeX->TurnFz();
				cubeX->TurnFz();
				break;

			case 'l':
				cubeX->Clockwise(R);
				cubeX->TurnRx();
				cubeX->TurnRx();
				cubeX->TurnRx();
				break;

			case 'r':
				cubeX->Clockwise(L);
				cubeX->TurnRx();
				break;

			case 'u':
				cubeX->Clockwise(D);
				cubeX->TurnUy();
				break;

			case 'd':
				cubeX->Clockwise(U);
				cubeX->TurnUy();
				cubeX->TurnUy();
				cubeX->TurnUy();
				break;
				
			case 'x':
				cubeX->TurnRx();
				break;
			case 'y':
				cubeX->TurnUy();
				break;
			case 'z':
				cubeX->TurnFz();
				break;

			case 'M':
				cubeX->Clockwise(R);
				cubeX->TurnRx();
				cubeX->TurnRx();
				cubeX->TurnRx();
				cubeX->Clockwise(L);
				cubeX->Clockwise(L);
				cubeX->Clockwise(L);
				break;
			case 'E':
				cubeX->Clockwise(U);
				cubeX->TurnUy();
				cubeX->TurnUy();
				cubeX->TurnUy();
				cubeX->Clockwise(D);
				cubeX->Clockwise(D);
				cubeX->Clockwise(D);
				break;
			case 'S':
				cubeX->Clockwise(B);
				cubeX->TurnFz();
				cubeX->Clockwise(F);
				cubeX->Clockwise(F);
				cubeX->Clockwise(F);
				break;
			default:
				break;
			}
		}
	}

	cubeX->getline(0);
	cout << templine <<endl;
	cubeX->getline(1);
	cout << templine <<endl;
	cubeX->getline(2);
	cout << templine <<endl;

	return 0;

}

