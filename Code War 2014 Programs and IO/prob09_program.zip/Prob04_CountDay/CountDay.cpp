#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>


int main(int argc, char* argv[] )
{
	int StartYear, StartMonth, StartDay;
	int EndYear, EndMonth, EndDay;
	int anykey;
	int days = 1;

	printf("Start Date : ");
    scanf_s("%d/%d/%d", &StartYear,&StartMonth, &StartDay);
	printf("End Date : ");
	scanf_s("%d/%d/%d", &EndYear,&EndMonth, &EndDay);

    if ((StartYear > 0 && StartMonth >= 1 && StartMonth <= 12 && StartDay >= 1 && StartDay <= 31) && (EndYear > 0 && EndMonth >= 1 && EndMonth <= 12 && EndDay >= 1 && EndDay <= 31)){
	  if (StartYear *10000 + StartMonth *100  + StartDay < EndYear *10000 + EndMonth *100  + EndDay){
        for (int i = StartYear; i < EndYear; i++) {
	      if ((i%4 == 0 && i%100 !=0) || i %400 == 0) {
	        days +=366;
		  } else {
		    days +=365;
		  }
	    }

	    for (int j =1; j < StartMonth; j++) {
	      if (j == 1 || j == 3 || j == 7 || j == 8 || j == 10 || j ==12) {
		    days -=31;
	      }else if(j == 4 || j == 6 || j == 9 || j == 11) {
		    days -=30;
	      }else if (j == 2) {
		    if ((StartYear % 4 == 0 && StartYear % 100 != 0) || StartYear % 400 == 0) {
	          days -= 29;
		    } else {
		      days -=28;
		    }
		  } 
		}	
        days -= StartDay;
              
	    for (int j =1; j < EndMonth; j++) {
	      if (j == 1 || j == 3 || j == 7 || j == 8 || j == 10 || j ==12) {
		    days +=31;
	      }else if(j == 4 || j == 6 || j == 9 || j == 11) {
	 	    days +=30;
	      }else if (j == 2) {
		    if ((EndYear % 4 == 0 && EndYear % 100 != 0) || EndYear % 400 == 0) {
	          days += 29;
		    } else {
		      days +=28;
		    }
		  }
	    }
        days += EndDay;
 	    printf("Total Days: %d days", days);
        return 0;
	  }
	}
	printf("Total Days: Invalid Input");
	return 0;
}