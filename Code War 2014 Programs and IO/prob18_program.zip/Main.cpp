#include <algorithm>

typedef struct _ROUTE {
  int s; // start point
  float p; // probability
  int e; // end point
  int isDone;
} ROUTE;

typedef struct _POINT {
  float p; // probability
  int isDone;
} POINT;

int mRouteNum = 0;
ROUTE * mRouteArray;

int mPointNum = 0;
POINT * mPointArray;

void SetRoute (ROUTE * route, int s, float p, int e)
{
  route->s = s;
  route->p = p;
  route->e = e;
  route->isDone = 0;
}

float Evaluate (int * array)
{
  int i, j;
  float score;
  
  //
  // If not satisfy Rule2, return 99999.........
  //
  
  for (i = 0; i < mRouteNum; i++) {
    for (j = 0; j < mPointNum; j++) {
      if (mRouteArray[i].s == array[j]) {
        break;
      }
      if (mRouteArray[i].e == array[j]) {
        return 99999.0;
      }
    }
    
  }
  
  score = 0;
  for (i = 0; i < mPointNum; i++) {
    score = score + mPointArray[array[i]].p * (i + 1);
  }
  return score;
}

int main( void )
{
  int i, j;
  float score;
  float bestScore;
  int *array;
  int *ans;
  float p;
  
  //
  // Input
  // (0,0.8,1)(1,0.01,3)(0,0.01,3)(0,0.1,2)(0, 0, 0)
  // (0,0.2,1)(1,0.01,3)(0,0.01,3)(0,0.9,2)(0, 0, 0)
  // (0,0.2,1)(1,0.01,3)(1,0.3,2)(2,0.1,3)(5,3,4)(2, 0.5, 4)(0,0.01,5)(0,0,0)
  //
  
  while (1) {
    scanf ("(%d,%f,%d)", &i, &p, &j);
    //printf ("==%d, %f, %d==\n", i, p, j);
    if (i == 0 && j == 0) {
      break;
    }
    
    mRouteNum++;
    if (mRouteNum == 1) {
      mRouteArray = (ROUTE *) malloc (sizeof (ROUTE));
    } else{
      mRouteArray = (ROUTE *) realloc (mRouteArray, mRouteNum * sizeof (ROUTE));
    }
    SetRoute (mRouteArray + mRouteNum - 1, i, p, j);
  }
  
  //printf ("mRouteNum %d\n", mRouteNum);
  
  mPointNum = 0;
  for (i = 0; i < mRouteNum; i++) {
    if (mPointNum < mRouteArray[i].e + 1) {
      mPointNum = mRouteArray[i].e + 1;
    }
  }
  
  //printf ("mPointNum %d\n", mPointNum);
  
  mPointArray = (POINT *) malloc (mPointNum * sizeof (POINT));
  memset (mPointArray, 0, mPointNum * sizeof (POINT));
  
  mPointArray[0].p = 1 ; // point 0's p is 1
  
  //
  // Get each point's probability
  //
  
  i = 0;
  j = 0;
  while (1) {
  
    if (!mRouteArray[i].isDone) {
      if (mRouteArray[i].s == 0) {
        mPointArray[mRouteArray[i].e].p = mRouteArray[i].p;
        mRouteArray[i].isDone = 1;
        j++;
      } else {
        if (mPointArray[mRouteArray[i].s].isDone) {
        
          mPointArray[mRouteArray[i].e].p = mPointArray[mRouteArray[i].e].p + mRouteArray[i].p * mPointArray[mRouteArray[i].s].p;
          mRouteArray[i].isDone = 1;
          j++;
        }
      }
    }
    
    if (i == mRouteNum - 1) {
      if (j == mRouteNum) {
        //
        // Every Route is done.
        //
        break;
      }
      
      //
      // Find which point is done, set its flag
      //

      for (i = 0; i < mPointNum; i++) {
        mPointArray[i].isDone = 1;
      }
      
      for (i = 0; i < mRouteNum; i++) {
        if (!mRouteArray[i].isDone) {
          
          mPointArray[mRouteArray[i].e].isDone = 0;
        }
      }

      i = 0; // reset i
    } else {
      i++;
    }
    
  }
  
  
  score = 0;
  for (i = 0; i < mPointNum; i++) {
    score = score + mPointArray[i].p * (i+1);
    //printf("i: %d, p: %f\n", i, mPointArray[i].p);
  }
  
  array = (int *) malloc (sizeof (int) * mPointNum);
  for (i = 0; i < mPointNum; i++) {
    array[i] = i;
  }
  
  ans = (int *) malloc (sizeof (int) * mPointNum);
  bestScore = Evaluate (array);
  for (i = 0; i < mPointNum; i++) {
    ans[i] = array[i];
  }
  
  //
  // Evaluate score with every permutation
  //
  
  do {
    //printf ("%d, %d, %d, %d\n", array[0], array[1], array[2], array[3]);
    score = Evaluate (array);
    //printf ("score %f\n", score);
    if (score < bestScore) {
      bestScore = score;
      for (i = 0; i < mPointNum; i++) {
        ans[i] = array[i];
      }
    }
  } while ( std::next_permutation(array,array+mPointNum) );
  
  //printf ("BestScore: %f\n", bestScore);


  for (i = 0; i < mPointNum - 1; i++) {
    printf ("%d,", ans[i]);
  }
  printf ("%d", ans[i]);

  return 0;
}
