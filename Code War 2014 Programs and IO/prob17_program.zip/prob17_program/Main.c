#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h> 

typedef unsigned __int8 bool;
#define false 0
#define true 1

#define LARGE_NUMBER 100000000

//
// 0~25 == A~Z
//

double w[26][26]; // w[0][1] is shortest time of A to B
double d[26]; // d[0] is the shortest time of start point to A
int parent[26];

bool visit[26];

int PointToIndex (char c) 
{
  return (int) c - (int) 'A';
}
char IndexToPoint (int c) 
{
  return (char)((int) 'A' + c);
}
void Build (char *str) {
  int i, j;
  char s, e;
  int len, speed;
  double time;
  char traffic[10];
  
  //A B 30 50 Light
  sscanf (str,"%c %c %d %d %s\n",&s, &e, &len, &speed, traffic);
  i = PointToIndex (s);
  j = PointToIndex (e);
  if (strcmp(traffic, "Light") == 0) {
    time = (double)len / ((double)speed * 1.0);
  } else if (strcmp(traffic, "Medium") == 0) {
    time = (double)len / ((double)speed * 0.6);
  } else {
    time = (double)len / ((double)speed * 0.3);
  }
  if (time < w[i][j]) {
    w[i][j] = time;
    w[j][i] = time;
  }
}

void FindPath (int x) 
{
  if (x != parent[x]) {
    FindPath(parent[x]);
  }
  printf ("%c ",IndexToPoint(x));

}

int Round(double d)
{
    if(d >= 0.0f)
    {
        return ((int)(d + 0.5f));
    }
    return ((int)(d - 0.5f));
}

int main( void )
{ 
  int i, j, k;
  int s, e;
  char *str;
  char buffer[100];
  
  for (i = 0; i < 26; i++) {
    d[i] = LARGE_NUMBER;
    for (j = 0; j < 26; j++) {
      w[i][j] = LARGE_NUMBER;
    }
  }
  
  i = 0;
  do {
    str = fgets(buffer, 100, stdin);
  if (i == 0) {
    s = PointToIndex(*str);
    i++;
    continue;
  } else if (i == 1) {
     e = PointToIndex(*str);
     i++;
     continue;
  }

    if (*str!='\n' && *str!='0') {
      Build(str);
    }
    if (*str == '0') {
      break;
    }
  } while (*str!='\n' && *str!='0');
  
  for (i = 0; i < 26; i++) {
    visit[i] = false;
  }
  for (i = 0; i < 26; i++) {
    d[i] = w[s][i];
  }
  d[s] = 0;
  parent[s] = s;
  //visit[s] = true;

  for (k = 0; k < 26 - 1; k++) {
    int a = -1;
    int b = -1;
    double min = LARGE_NUMBER;
    
    for (i=0; i<26; i++) {
      if (!visit[i] && d[i] < min) {
        a = i;
        min = d[i];
      }
  }

    if (a == -1) break;
    if (k == s) {
      d[a] = min;
    }
    visit[a] = true;

    
    for (b=0; b<26; b++) {
      if (b == 18) {
      int dd = 0;
      dd=1;
      }
      if (!visit[b] && d[a] + w[a][b] <= d[b]) {
        d[b] = d[a] + w[a][b];
        parent[b] = a;
      }
    }
  }
  FindPath(e); // already print path inside function
  //printf ("%d, %f\n",e, d[e]);
  printf ("%d:%d\n", (int) d[e], Round(d[e]*60)%60);
  return 0;
}
