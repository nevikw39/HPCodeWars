#include <cstdlib>
#include <iostream>
#include <cmath>
#include <string.h>
#include <vector>
using namespace std;

int main(int argc, char *argv[])
{
    char    *nstr= "#%$&\\~!@";
    int     number[]= {0,1,2,3,4,5,6,-1};
    string input;
    vector<string> vstr;
    char *pool;
    long int sum =0;
    do{
        cin >> input;

        if (input != "0") 
            vstr.push_back(input);
    }while( input!="0");
    
    for (int i=0; i < vstr.size();i++){ 
        input = vstr[i];
        sum = 0 ;
        pool = new char[input.size()];
        memset(pool,0,input.size());
        memcpy(pool,input.c_str(), input.size());
        //cout <<  pool << '\n';
        for (int i =1; i < input.size()+1; i++ ){
            //cout << pool[input.size()-i] << " >>> ";
            for (int j =0;j<8; j++){
                if (pool[input.size()-i] != nstr[j]) continue;
                //cout <<  sum << " + " <<  number[j] << "* 7^" << i << '\n'; 
                sum += number[j]*pow(7,i-1);
            } 
        }
        //cout << "Press the enter key to continue ...";
        cout << (int)sum << '\n';
        delete pool;
    }
 //   system("pause");
    return EXIT_SUCCESS;
}
