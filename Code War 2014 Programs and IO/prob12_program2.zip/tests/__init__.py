#!/usr/bin/env python
# -*- coding: utf-8 -*-

import unittest
from textwrap import dedent
from ..mm import Solver

class Base(unittest.TestCase):
    def assertCells(self, solver, start, end, values):
        i = 0
        for iy in range(start[1], end[1] + 1):
            for ix in range(start[0], end[0] + 1):
                actual = solver.cell[ix, iy]
                expect = values[i]
                self.assertEqual(
                    actual, expect,
                    "Cell(%d, %d) is '%s', not '%s'" % (ix, iy, actual, expect)
                )
                i = i + 1

class TestOneStep(Base):
    def setUp(self):
        maze = dedent("""\
        @@@
        -*@
        @@@
        """)

        self.solver = Solver()
        for line in maze.split("\n"):
            self.solver.append(line)

    def tearDown(self):
        pass

    def testDimension(self):
        self.assertEqual(self.solver.width, 3)
        self.assertEqual(self.solver.height, 3)

    def testCell(self):
        self.assertCells(self.solver, (-1, -1), (3, 3), [
            '@', '@', '@', '@', '@',
            '@', '@', '@', '@', '@',
            '@', '-', '*', '@', '@',
            '@', '@', '@', '@', '@',
            '@', '@', '@', '@', '@',
        ])

    def testStart(self):
        self.assertEqual(self.solver.start, (0, 1))

    def testEnd(self):
        self.assertEqual(self.solver.end, (1, 1))

    def testSolve(self):
        self.solver.solve()
        self.assertCells(self.solver, (0, 0), (2, 2), [
            '@', '@', '@',
            '→', '*', '@',
            '@', '@', '@',
        ])

    def testResult(self):
        self.solver.solve()
        self.assertEqual(self.solver.result,
                         dedent("""\
                         Minimum distance: 0 steps
                         @@@
                         -*@
                         @@@"""))

class TestTwoSteps(Base):
    def setUp(self):
        maze = dedent("""\
        @@@@
        - *@
        @@@@
        """)

        self.solver = Solver()
        for line in maze.split("\n"):
            self.solver.append(line)

    def testSolve(self):
        self.solver.solve()
        self.assertCells(self.solver, (0, 0), (3, 2), [
            '@', '@', '@', '@',
            '→', '→', '*', '@',
            '@', '@', '@', '@',
        ])

    def testResult(self):
        self.solver.solve()
        self.assertEqual(self.solver.result,
                         dedent("""\
                         Minimum distance: 1 steps
                         @@@@
                         -.*@
                         @@@@"""))

class TestTurn(Base):
    def setUp(self):
        maze = dedent("""\
        @@@@@
        -  @@
        @ @@@
        @ @*@
        @   @
        @@@@@
        """)

        self.solver = Solver()
        for line in maze.split("\n"):
            self.solver.append(line)

    def testResult(self):
        self.solver.solve()
        self.assertEqual(self.solver.result,
                         dedent("""\
                         Minimum distance: 6 steps
                         @@@@@
                         -. @@
                         @.@@@
                         @.@*@
                         @...@
                         @@@@@"""))

class TestComplex(Base):
    def setUp(self):
        maze = dedent("""\
        @@@@@@@@@@@@@@@@@@@@
        -                  @
        @@@@@@@@@@@@@@@@@@ @
        @        *@      @ @
        @@@ @ @@@@@ @@@@@@ @
        @ @ @ @        @ @ @
        @ @@@ @@@@@@@@@@ @ @
        @     @     @    @ @
        @ @@@@@ @ @ @@@@@@ @
        @ @     @ @      @ @
        @ @ @@@@@ @@@@@@@@ @
        @ @    @    @      @
        @ @@@@@@@@@@@@ @@@@@
        @        @   @     @
        @@@@ @@@ @@@@@@@@@ @
        @  @ @           @ @
        @ @  @@@@@@@@@@@ @ @
        @ @ @          @ @ @
        @ @@@@@@@@@@@@@@   @
        @                  @
        @@@@@@@@@@@@@@@@@@@@
        """)

        self.solver = Solver()
        for line in maze.split("\n"):
            self.solver.append(line)

    def testResult(self):
        self.solver.solve()
        self.assertEqual(self.solver.result,
                         dedent("""\
                         Minimum distance: 82 steps
                         @@@@@@@@@@@@@@@@@@@@
                         -..................@
                         @@@@@@@@@@@@@@@@@@.@
                         @    ....*@      @.@
                         @@@ @.@@@@@ @@@@@@.@
                         @ @ @.@        @ @.@
                         @ @@@.@@@@@@@@@@ @.@
                         @.....@     @    @.@
                         @.@@@@@ @ @ @@@@@@.@
                         @.@     @ @      @.@
                         @.@ @@@@@ @@@@@@@@.@
                         @.@    @    @ .....@
                         @.@@@@@@@@@@@@.@@@@@
                         @........@   @.....@
                         @@@@ @@@.@@@@@@@@@.@
                         @  @ @  .........@.@
                         @ @  @@@@@@@@@@@.@.@
                         @ @ @          @.@.@
                         @ @@@@@@@@@@@@@@...@
                         @                  @
                         @@@@@@@@@@@@@@@@@@@@"""))
