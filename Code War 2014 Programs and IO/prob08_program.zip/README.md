# Base 7 Converter

Base 7 converter implementation for HP CodeWars 2014.

## Execute

`main.py` takes arguments from stdin:

    $ python main.py < sample.txt
    311
    230
    -390

## Unit test

    $ pip install -r dev-requirements.txt
    $ nosetests --with-coverage
