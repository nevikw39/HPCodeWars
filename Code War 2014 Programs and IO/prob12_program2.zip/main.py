import fileinput
from mm import Solver

s = Solver()
for line in fileinput.input():
    s.append(line.strip())

print s.result
