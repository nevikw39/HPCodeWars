import unittest
from ..uu import Converter

class TestUU(unittest.TestCase):
    def setUp(self):
        pass

    def tearDown(self):
        pass

    def testValue(self):
        self.assertEqual(Converter("U+0024").value, 0x0024)
        self.assertEqual(Converter("U+00A2").value, 0x00A2)
        self.assertEqual(Converter("U+20AC").value, 0x20AC)
        self.assertEqual(Converter("U+24B62").value, 0x24B62)

    def testLength(self):
        self.assertEqual(Converter("U+0000").length, 1)
        self.assertEqual(Converter("U+0055").length, 1)
        self.assertEqual(Converter("U+007F").length, 1)

        self.assertEqual(Converter("U+0080").length, 2)
        self.assertEqual(Converter("U+0555").length, 2)
        self.assertEqual(Converter("U+07FF").length, 2)

        self.assertEqual(Converter("U+0800").length, 3)
        self.assertEqual(Converter("U+5555").length, 3)
        self.assertEqual(Converter("U+FFFF").length, 3)

        self.assertEqual(Converter("U+10000").length, 4)
        self.assertEqual(Converter("U+55555").length, 4)
        self.assertEqual(Converter("U+155555").length, 4)
        self.assertEqual(Converter("U+1FFFFF").length, 4)

    def testCode(self):
        self.assertEqual(Converter("U+0024").code,
                         (0b0100100,))
        self.assertEqual(Converter("U+00A2").code,
                         (0b00010, 0b100010))
        self.assertEqual(Converter("U+20AC").code,
                         (0b0010, 0b000010, 0b101100))
        self.assertEqual(Converter("U+24B62").code,
                         (0b000, 0b100100, 0b101101, 0b100010))

    def testResult(self):
        self.assertEqual(Converter("U+0024").result, "24")
        self.assertEqual(Converter("U+00A2").result, "C2A2")
        self.assertEqual(Converter("U+20AC").result, "E282AC")
        self.assertEqual(Converter("U+24B62").result, "F0A4ADA2")
