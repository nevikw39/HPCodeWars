import fileinput
from bs import Converter

for line in fileinput.input():
    if '0' in line:
        break
    c = Converter(line)
    print c.result
