#include <stdio.h>
#include <stdlib.h>
#include <string.h>

FILE *file = NULL;
char a[21][22];

//dir: 1 = up, 2 = down, 3 = left, 4 = right
bool step(int i, int j, int dir) {
    
    if (a[i][j] == 42) {return true;}
    
    bool up = false, down = false, left = false, right = false;
    a[i][j] = 65;
    system("CLS");
    for(int i =0;i<21;i++){
            for(int j=0;j<21;j++){
                     printf("%c",a[i][j]);
             }   
    }
   
    if ((i-1 > 0  && a[i-1][j] == 32)||(i-1 > 0  && a[i-1][j] == 42)){up = true;printf("up, ");};
    if ((i+1 < 21 && a[i+1][j] == 32)||(i+1 < 21 && a[i+1][j] == 42) ){down = true;printf("down, ");};
    if ((j-1 > 0  && a[i][j-1] == 32)||(j-1 > 0  && a[i][j-1] == 42)){left = true;printf("left, ");};
    if ((j+1 < 20 && a[i][j+1] == 32)||(j+1 < 20 && a[i][j+1] == 42)){right = true;printf("right, ");};
    
    if      (dir == 1){up = false;         printf("from up, ");}
    else if (dir == 2){down = false;       printf("from down, ");}
    else if (dir == 3){left = false;       printf("from left, ");}
    else if (dir == 4){right = false;      printf("from right, ");}
    //printf("\n");
    
    
    if(up){printf("[up ok]");}if(down){printf("[down ok]");}if(left){printf("[left ok]");}if(right){printf("[right ok]");}
    
    if (up      == true){printf("go up\n");system("pause");        up    = step(i-1,j,2);};
    if (down    == true){printf("go down\n");system("pause");    down  = step(i+1,j,1);};
    if (left    == true){printf("go left\n");system("pause");      left  = step(i,j-1,4);};
    if (right   == true){printf("go right\n");system("pause");     right = step(i,j+1,3);};
    
    if (up == false && down == false && left == false && right == false) { a[i][j] = 32; return false;}
    else {a[i][j] = 32; return true;}
    
}





int main() {
            bool result = false;
            file = fopen("maze.txt","r");
            if (file != NULL) printf("success\n");
            else if (file == NULL) printf("read failed\nPlease put your maze into maze.txt");
            int start_x, start_y, start_direction;   
                  
            for (int i = 0; i < 21; i++) {
                   fgets(&(a[i][0]),22,file);
                   if (feof(file)) break;
                   for (int j=0; j < strlen(&(a[i][0])); j++) {
                     //printf("%d",a[i][j]);                    
                }
                
                //printf("\n");
                }      

                for(int i =0;i<21;i++){
                        for(int j=0;j<21;j++){
                                if(a[i][j] == 45){
                                  start_x = i;
                                  start_y = j;                    
                                }
                                //printf("%d",a[i][j]);
                        }
                    //printf("\n");    
                }
            //printf ("start: (%d, %d)", start_x, start_y);    
            //system("pause");
            
            
            if (start_x == 0 && start_y > 0 && start_y < 20){
                  start_direction = 1;
            } else if (start_x > 0 && start_x < 20 && start_y == 0) {
                   start_direction = 3;
            } else if (start_x == 20 && start_y > 0 && start_y < 20) {
                   start_direction = 2;
            } else if (start_y == 19 && start_x > 0 && start_x < 20) {
                   start_direction = 4;
            } else {
              printf ("Start point ERROR!! \n");  
              system("pause");          
            }
            
            result = step(start_x,start_y,start_direction);
            if (result == true){printf("\nresult:true\n");}
            else if (result == false){printf("\nresult:failed\n");}
                  
                  system("pause");
            return 0;
     
     }
