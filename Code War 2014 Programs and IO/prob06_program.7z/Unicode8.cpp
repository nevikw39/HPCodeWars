
#include <iostream>
#include <string>


using namespace std;

//int main(int argc, char* argv[])
int main (void)
{
	char s[10]="";
	string num="";
	int i=0;
	int hex_num;
	int qtf8=0;
	


  	//cout<<"Please enter a unicode"<<endl;
	  cin>>s;

		if ((s[0]=='U')&&(s[1]=='+')) {
			//num="0x";
			for (unsigned int j=2; j<strlen(s);j++)
			{
				num+=s[j];
			}
			//printf("num=%s ",num.c_str());
			
			hex_num=strtol(num.c_str(),NULL,16);
			//printf("hex_num=%x\n",hex_num);

			if ( (hex_num>=0)&&(hex_num<=0x7f) ){
				printf("%02X\n",hex_num);
			}
			else if ( (hex_num>=0x80)&&(hex_num<=0x7ff) ){
				printf("%X\n",(0x80|(hex_num&0x3f))| ((hex_num>>6 &0x1f)|0xc0)<<8);

			}
			else if ( (hex_num>=0x800)&&(hex_num<=0xffff) ){
				printf("%X\n",(0x80|(hex_num&0x3f))|((0x80|(hex_num>>6 &0x3f))<<8) | ((0xe0|(hex_num>>12 &0x0f))<<16) );
				
			}
			else if ( (hex_num>=0x10000)&&(hex_num<=0x1fffff) ){
				printf("%X\n",(0x80|(hex_num&0x3f))|((0x80|(hex_num>>6 &0x3f))<<8) | ((0x80|(hex_num>>12 &0x3f))<<16) | ((0xf0|(hex_num>>18 &0x07))<<24));
			}
		}
		else
		{
			cout<<"Invalid Input"<<endl;
		}
		num.clear();
		
	return 0;
}
