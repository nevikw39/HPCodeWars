import fileinput
from uu import Converter

for line in fileinput.input():
    c = Converter(line)
    print c.result
