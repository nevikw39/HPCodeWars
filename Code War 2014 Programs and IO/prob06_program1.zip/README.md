# Unicode → UTF-8

Unicode → UTF-8 converter implementation for HP CodeWars 2014.

## Execute

`main.py` takes arguments from stdin:

    $ echo "U+0024" > prog.txt
    $ python main.py < prog.txt
    24

Or:

    $ echo "U+00A2" | python main.py
    C2A2
    $ echo "U+20AC" | python main.py
    E282AC

## Unit test

    $ pip install -r dev-requirements.txt
    $ nosetests --with-coverage
