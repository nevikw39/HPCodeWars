import unittest
from ..game import Game

class TestGame(unittest.TestCase):
    def setUp(self):
        pass

    def tearDown(self):
        pass

    def testParse(self):
        game = Game("4 2 01111110 1")
        self.assertEqual(game.width, 4)
        self.assertEqual(game.height, 2)
        self.assertEqual(game.generation, 1)

    def testBound(self):
        game = Game("4 2 01111110 1")
        start, end = game.bound
        self.assertEqual(start, {'x': 0, 'y': 0})
        self.assertEqual(end, {'x': 4, 'y': 2})

    def assertCells(self, game, start, end, values):
        i = 0
        for iy in range(start[1], end[1] + 1):
            for ix in range(start[0], end[0] + 1):
                self.assertEqual(
                    game.cell[ix, iy],
                    values[i],
                    "Cell(%d, %d) != %s" % (ix, iy, values[i])
                )
                i = i + 1

    def assertSurrounds(self, game, start, end, values):
        i = 0
        for iy in range(start[1], end[1] + 1):
            for ix in range(start[0], end[0] + 1):
                self.assertEqual(
                    game.surround[ix, iy],
                    values[i],
                    "Surround(%d, %d) is %d, not %d" % (ix,
                                                        iy,
                                                        game.surround[ix, iy],
                                                        values[i])
                )
                i = i + 1

    def testCell(self):
        game = Game("4 2 01111110 1")

        self.assertCells(game, (-1, -1), (4, 2), [
            False, False, False, False, False, False,
            False, False, True,  True,  True,  False,
            False, True,  True,  True,  False, False,
            False, False, False, False, False, False,
        ])

    def testSurround(self):
        game = Game("4 2 01111110 1")

        self.assertSurrounds(game, (-1, -1), (4, 2), [
            0, 1, 2, 3, 2, 1,
            1, 3, 4, 4, 2, 1,
            1, 2, 4 ,4, 3, 1,
            1, 2, 3, 2, 1, 0,
        ])

    def testStep(self):
        game = Game("4 2 01111110 1")
        steps = game.steps
        game.step()

        self.assertCells(game, (-1, -1), (4, 2), [
            False, False, False, True,  False, False,
            False, True,  False, False, True,  False,
            False, True,  False, False, True,  False,
            False, False, True,  False, False, False,
        ])
        self.assertEqual(steps + 1, game.steps)

    def testStepAndBound(self):
        game = Game("4 2 01111110 1")
        game.step()
        start, end = game.bound
        self.assertEqual(start, {'x': 0, 'y': -1})
        self.assertEqual(end, {'x': 4, 'y': 3})

    def testRun(self):
        game = Game("4 2 01111110 1")
        self.assertEqual(game.steps, 0)
        game.run()
        self.assertCells(game, (-1, -1), (4, 2), [
            False, False, False, True,  False, False,
            False, True,  False, False, True,  False,
            False, True,  False, False, True,  False,
            False, False, True,  False, False, False,
        ])
        self.assertEqual(game.steps, game.generation)

    def testRun2(self):
        game = Game("4 2 01111110 2")
        self.assertEqual(game.steps, 0)
        game.run()
        self.assertCells(game, (-1, -1), (4, 2), [
            False, False, False, False, False, False,
            False, False, True,  True,  True,  False,
            False, True,  True,  True,  False,  False,
            False, False, False, False, False, False,
        ])
        self.assertEqual(game.steps, game.generation)

    def testDumps(self):
        game = Game("4 2 01111110 1")
        game.run()
        self.assertEqual(game.result, "4 4 0010100110010100")

    def testDumps2(self):
        game = Game("4 2 01111110 2")
        game.run()
        self.assertEqual(game.result, "4 2 01111110")

    def testEmpty(self):
        game = Game("1 1 1 1")
        game.run()
        self.assertEqual(game.result, "0 0")

    def testEmpty2(self):
        game = Game("1 1 1 4")
        game.run()
        self.assertEqual(game.result, "0 0")

    def testGrow(self):
        game = Game("3 2 010111 3")
        game.run()
        start, end = game.bound
        self.assertEqual(start, {'x': 0, 'y': -1})
        self.assertEqual(end, {'x': 3, 'y': 4})

