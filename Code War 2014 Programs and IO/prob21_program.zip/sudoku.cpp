#include <cstdlib>
#include <iostream>
#include <vector>
#include <string.h>
#include <new>


using namespace std;
struct UNKNOWN{
    vector<char> data;
};
struct RECORD{
	int offset;
	int data;
	char *array;
	RECORD *next;
	RECORD *previous;
};



RECORD rec_head; 
#define PAUSE system("pause")
#define step 0
#define debug 0

void Rule1_xyb();
void trynerror();
UNKNOWN unknown[90];
char ptr[90];
char ptr_back[90];
char number[]="123456789";
int TNE=1;

int find_char(vector<char> data, char patten ){
    int i;
    for (i=0;i<data.size();i++){
        if (data[i]==patten)
            return true;
    }
    return false;
}

int check_stick_x(vector<char> stick){
    int i;
    char box_x=0;
    for (i=1;i<stick.size();i++){   
        if (i == 1){
            box_x = ((stick[i])%10)/3;
        }else{
            if ( ((stick[i])%10)/3!=box_x )
                return -1;
        }
    }    
    return box_x;    
}
 

int check_stick_y(vector<char> stick){
    int i;
    char box_y=0;
    for (i=1;i<stick.size();i++){   
        if (i == 1){
            box_y = ((stick[i])/10)/3;
        }else{
            if ( ((stick[i])/10)/3!=box_y )
                return -1;
        }
    }    
    return box_y;    
}

int CheckDone(){
    int i,j,x,y;

	for (y=0;y<9;y++) {
		for(x=0;x<9;x++) {
            if (ptr[x+(10*y)]=='-')
               return 1;
        }
    }   
    return 0; 
}
void input_matrix(int input_method){
    char *sudoku[]= {

		"--9---7--",
		"-5-9-2-8-",
		"4-------3",
		"-8-3-4-7-",
		"----2----",
		"-3-7-5-9-",
		"9-------4",
		"-6-4-3-2-",
		"--1---5--"
/*819536742
357942681
426187953
185394276
794628315
632715498
973251864
568473129
241869537*/
/*
"8-------4",
"-2-4-3-7-",
"--4-7-9--",
"-1-3-5-6-",
"--9---5--",
"-3-6-2-9-",
"--7-5-2--",
"-5-9-7-4-",
"1-------6"

875269314
921483675
364571982
712395468
649718523
538642197
487156239
256937841
193824756*/
    };
	if (input_method) {
		cin >> ptr+ 0;
		cin >> ptr+ 10;
		cin >> ptr+ 20;
		cin >> ptr+ 30;
		cin >> ptr+ 40;
		cin >> ptr+ 50;
		cin >> ptr+ 60;
		cin >> ptr+ 70;
		cin >> ptr+ 80;
		return;
	}

	memcpy (ptr, sudoku[0], 90);
}
void output_result(){


	for (int i=0;i<90;i++) {
		if (i==9) {
			ptr[i] =0;
		}else{
            if (unknown[i].data.size()==1) {
				ptr[i] = unknown[i].data[0];
			}
		}
	}

	cout << ptr << '\n';
	cout << ptr+10 << '\n';
	cout << ptr+20 << '\n';
	cout << ptr+30 << '\n'; 
	cout << ptr+40 << '\n';
	cout << ptr+50 << '\n';
	cout << ptr+60 << '\n';
	cout << ptr+70 << '\n';
	cout << ptr+80 << '\n';
}

void output_array(char *array){

	cout << array << '\n';
	cout << array+10 << '\n';
	cout << array+20 << '\n';
	cout << array+30 << '\n'; 
	cout << array+40 << '\n';
	cout << array+50 << '\n';
	cout << array+60 << '\n';
	cout << array+70 << '\n';
	cout << array+80 << '\n';
}

void fill_in_possible_data(){
	int i,j,x,y,n,n1,k,x1,y1;
	char variable_temp;
    vector<char> variable;
    vector<char> stick,temp;
    int box_x, box_y;    
	for (y=0;y<9;y++) {
		for(x=0;x<9;x++) {
            //x=4;y=0;
			if (*(ptr+x+(10*y))!='-'){
				unknown[x+(10*y)].data.clear();
				unknown[x+(10*y)].data.push_back(*(ptr+x+(10*y)));
//				break;
			}else{
				variable.clear();
				for (i=0;i<9;i++){
					for (j=0;j<9;j++){
						if (number[i]==*(ptr+j     + (y*10) )){
							j-=1;
							break; //x
						}
						if (number[i]==*(ptr+(j*10)+  x     )){
							j-=1;
							break; //y
						}
						if (number[i]==*(ptr+(j%3)+((x/3)*3)+ (((j/3)+((y/3)*3))*10)) ){
							j-=1;
							break;  //block
						}
					}
					if (j==9){
						variable.push_back(number[i]);

					}       
				}
				unknown[x+(10*y)].data.clear();
				for (i=0;i<variable.size();i++){
                    if (variable.size() ==1) {
                        *(ptr+x+(10*y)) = variable[i];
                        TNE = 0 ;
#if step					
					cout << "F \n" ;
                    cout << x << y << variable[i]  ;
                        PAUSE;				
#endif             
                        x=0;y=0;
                        break;
                    }
					variable_temp = variable[i];
				    unknown[x+(10*y)].data.push_back(variable_temp);
				}
 
			}
		}
	}





    
    //if number not in other block's X , then kill the number in ~y of that block.
    // use string to find out the data. 

   // cout << ((unknown[3].data,itoa(n)))?"True":"False");
    
    
    
	for (y=0;y<90;y+=10) {
		for (n=0;n<9;n++){
            stick.clear();
            stick.push_back(n);
            //cout << "Y = " << (int)(y/10) << ' ';
            //cout << "targer = " << (n+1) << ' ';
            //cout << "X = ";
            for (x1=0;((x1<9) && (stick.size()<=4));x1++){            
                if (find_char(unknown[y+x1].data,number[n])){
                    stick.push_back(y+x1);
                    //cout << (int )x1;
                }
            }
            
            if  (stick.size()>4) continue;
            if  (stick.size()<=2) continue;
            //cout << '\n' ;
            box_x = check_stick_x(stick);
            if (box_x == -1) continue;
            for (y1=(y/30)*30 ; y1 <((y/30)+1)*30 ; y1 +=10){
                if (y1 == y ) continue; 
                //cout << " Y1 = " << y1+(box_x*3) << '\n';
                for (x1 = 0 ; x1<3 ;x1 ++){
                    
                    temp = unknown[y1+(box_x*3)+x1].data;
                    //cout << "\n "<< y1+(box_x*3)+x1 << " = " ;
                    unknown[y1+(box_x*3)+x1].data.clear();
                    for (n1=0,k=0;n1<temp.size();n1++){
                        if (number[stick[0]] != temp[n1])
                            unknown[y1+(box_x*3)+x1].data.push_back( temp[n1]) ;  
                    }
                }
            }  
		}    
	//	PAUSE;
	}

	for (x=0;x<9;x+=1) {
		for (n=0;n<9;n++){
            stick.clear();
            stick.push_back(n);
            //cout << "Y = " << (int)(y/10) << ' ';
            //cout << "targer = " << (n+1) << ' ';
            //cout << "X = ";
            for (y1=0;((y1<90) && (stick.size()<=4));y1+=10){            
                if (find_char(unknown[x+y1].data,number[n])){
                    stick.push_back(x+y1);
                    //cout << (int )x1;
                }
            }
            
            if  (stick.size()>4) continue;
            if  (stick.size()<=2) continue;
            //cout << '\n' ;
            box_y = check_stick_y(stick);
            if (box_y == -1) continue;
            //cout << "box "<< box_x ;
            for (x1=(x/3)*3 ; x1 <((x/3)+1)*3 ; x1 +=1){
                if (x1 == x ) continue; 
                //cout << " Y1 " << y1;
                for (y1 = 0 ; y1<30 ;y1 +=10){
                    temp = unknown[y1+(box_y*30)+x1].data;
                    //cout << "\n "<< y1+(box_x*3)+x1 << " = " ;
                    unknown[y1+(box_y*30)+x1].data.clear();
                    for (n1=0,k=0;n1<temp.size();n1++){
                        if (number[stick[0]] != temp[n1])
                            unknown[y1+(box_y*30)+x1].data.push_back( temp[n1]) ;  
                    }
                }
            }  
		}    
	}
/*
    for (x=0;x<90;x++){
        if (unknown[x].data.size()<=1) continue;
        cout << x << " = ";
        for (n=0;n<unknown[x].data.size();n++)
            cout << unknown[x].data[n];
        cout << '\n'; 
    }
*/
/*
	for (i=0;i<90;i++) {
		if (i==9) {
			ptr[i] =0;
		}else{
            if (unknown[i].data.size()==1) {
				ptr[i] = unknown[i].data[0];
			}
		}
    }
 */
/*
	cout << ptr << '\n';
	cout << ptr+10 << '\n';
	cout << ptr+20 << '\n';
	cout << ptr+30 << '\n'; 
	cout << ptr+40 << '\n';
	cout << ptr+50 << '\n';
	cout << ptr+60 << '\n';
	cout << ptr+70 << '\n';
	cout << ptr+80 << '\n';
*/
//    PAUSE;   
  

//                    for (j=0;j<unknown[4/*i+ (y*10)*/].data.size();j++)
//                       cout << unknown[4].data[j];
 //                   cout << '\n';   	
}
void global_variable_init (){
    memset(&unknown, 0 , sizeof(unknown));
	rec_head.offset=-1;
	rec_head.data=-1;
	rec_head.array=NULL;
	rec_head.next=NULL;
	rec_head.previous=&rec_head;

	for (int i=0;i<81;i++)	
        fill_in_possible_data();
}

int main(int argc, char *argv[])
{
    vector<char> variable;   
	memset(ptr ,0, 90);
    int i=0,j=0,k=0,flag_only_one;
	char temp,check;
    int x,y; // 0-8, 9 = \n

	input_matrix(1);  // 0: internal test matrix; 1: external input;

	global_variable_init();


    while (CheckDone()){ 
        TNE=1;
        Rule1_xyb();
	    fill_in_possible_data();
        if (TNE){
            trynerror();
        } 
    } 

	for (i=0;i<90;i++) {
		if (i==9) {
			ptr[i] =0;
		}else{
            if (unknown[i].data.size()) {
				ptr[i] = unknown[i].data[0];
			}
		}
	}

	output_result();
	PAUSE;    
    return EXIT_SUCCESS;
}

void Rule1_xyb(){
    int x,y,i,j,k,check,flag_only_one;
	for (y=0;(y<9);y++) {
		for(x=0;(x<9);x++) {
            if (unknown[x+(10*y)].data.size()==1){
     			*(ptr+x+(10*y)) = unknown[x+(10*y)].data[0];
                fill_in_possible_data();
                continue;
            }
			for (k=0;k<unknown[x+(10*y)].data.size();k++){
                check = unknown[x+(10*y)].data[k];
                flag_only_one =0;
    		    for (i=0;i<9;i++){	    		    				
					// check x axis
                    if (flag_only_one>2)break;          
					for (j=0;j<unknown[i+ (y*10)].data.size();j++){
                        if (unknown[i+ (y*10)].data.size()==1) break;
					    if (check == unknown[i+ (y*10)].data[j]){
							flag_only_one ++;							
#if debug                     							
							cout << unknown[i+ (y*10)].data[j];
#endif							
						}
#if debug                     						
						cout <<'\n';
#endif						
					}				
			    }
				if (flag_only_one==1){
				    unknown[x+(10*y)].data.clear();
					unknown[x+(10*y)].data.push_back(check);
					*(ptr+x+(10*y)) = check;
					TNE=0;
#if step					
					cout << "X\n" ;
                    cout << x << y << check  ;
					PAUSE;
#endif                        
					fill_in_possible_data();
					x=0;y=0;flag_only_one=0;
					break;				
				}
				
				flag_only_one =0;
    		    for (i=0;(i<9);i++){	    		    				
					// check y axis
                    if (flag_only_one>2)break;				
					for (j=0;j<unknown[(i*10)+x].data.size();j++){
                        if (unknown[(i*10)+x].data.size()==1) break;
					    if (check == unknown[(i*10)+x].data[j]){
							flag_only_one++;
						}
					}
				}
				if (flag_only_one==1){
				    unknown[x+(10*y)].data.clear();
					unknown[x+(10*y)].data.push_back(check);
					*(ptr+x+(10*y)) = check;
                    TNE=0;				
#if step										
					cout << "Y\n" ;
                    cout << x << y << check  ;
                    PAUSE;
#endif                       
					fill_in_possible_data();
					x=0;y=0;flag_only_one=0;
					break;				
				}		
				flag_only_one =0;

    		    for (i=0;i<9;i++){	    		    				
					// check block
                    if (flag_only_one>2)break;				
					for (j=0;j<unknown[(i%3)+((x/3)*3)+ (((i/3)+((y/3)*3))*10)].data.size();j++){
                        if (unknown[(i%3)+((x/3)*3)+ (((i/3)+((y/3)*3))*10)].data.size()==1) break;
					    if (check == unknown[(i%3)+((x/3)*3)+ (((i/3)+((y/3)*3))*10)].data[j]){
							flag_only_one ++;
						}
					}
				}
				if (flag_only_one==1){
				    unknown[x+(10*y)].data.clear();
					unknown[x+(10*y)].data.push_back(check);
					*(ptr+x+(10*y)) = check;
					TNE=0;
#if step										
					cout << "B\n" ;
                    cout << x << y << check  ;
                    PAUSE;
#endif                      
					fill_in_possible_data();
					x=0;y=0;flag_only_one=0;
					break;				
				}	
                	
			}
		}
	}    
}

RECORD* get_last_record(){
	RECORD* LastRec;
	int i=0;
	LastRec = &rec_head;
	
	while (LastRec->next!=NULL) {
		LastRec = LastRec->next;
	}
	return LastRec ;
}

void del_last_record(){
	RECORD *LastRec, *NewTail;

	LastRec = get_last_record();
	if (LastRec != &rec_head){
	    NewTail = LastRec->previous;
	    NewTail->next =NULL;
	    if (LastRec->array) delete LastRec->array;
	    LastRec->array =NULL; 
	    if (LastRec) delete LastRec;
	    LastRec =NULL;
	    memcpy( ptr, NewTail->array, 90);
    }else{
	    if (LastRec->next) delete LastRec->next;  
        LastRec->next = NULL;
        memcpy( ptr, LastRec->array, 90);              
    }
	return;
}

void insert_new_record(){
	RECORD *NewRec,*OldRec,*TailRec;
	TailRec = get_last_record();
	if (TailRec->array != NULL) {
       // cout << "\nInsert\n";
		NewRec = new RECORD;
		NewRec->offset=TailRec->offset;
		NewRec->data=-1; // unknown data index
		NewRec->array=NULL;
		NewRec->next=NULL;
		NewRec->previous=TailRec;
		TailRec->next = NewRec;	
	}
}
void check_rec(){
	RECORD* LastRec;
	int i=0;
	LastRec = &rec_head;
	
	while (LastRec->next!=NULL) {
		cout << "rec index = " << i++ << '\n';
		cout << "offset = " << LastRec->offset << '\n';
		cout << "unknown data index = " << LastRec->data << '\n';
		if (LastRec->array) {
			output_array(LastRec->array);
		}else{
			cout << "array is NULL \n";
		}

		LastRec = LastRec->next;
	}
	PAUSE;
}
void trynerror() {
	int i,n;
	RECORD *rec;

	//check_rec();
	for(i=0;i<90;i++) {
		if (ptr[i]=='-') {
			rec = get_last_record();
			if (rec->offset < i){
                if (unknown[i].data.size()==0){
                    del_last_record();
                    //memcpy( ptr,rec_head.array,90);                                          
                    rec = get_last_record(); 
                    //memcpy (ptr , rec->array, 90);
                    fill_in_possible_data();
                    i = rec->offset;

                    break; 
                }
                
				insert_new_record();
				rec = get_last_record();
				rec->offset = i;
				rec->array = new char[90];
				memcpy(rec->array, ptr,90);			
			}	
            break;		
		}
	}
//	if (rec->data == unknown[i].data.size() -1) {
//		del_last_record();
//		return;
//	}
	
    for (n=0;n<unknown[i].data.size(); n++) {            
		if (rec->data == -1){
            rec->data = n;
            ptr[i] = unknown[i].data[n];
            fill_in_possible_data();
            break;
        }
		if (rec->data < n){
		    rec->data = n;
		    ptr[i] = unknown[i].data[n];
		    fill_in_possible_data();
		    break;
        }
	    if (n == unknown[i].data.size()-1) {
            del_last_record();
            n=-1;
            rec = get_last_record(); 
            fill_in_possible_data();
            i = rec->offset;  
            //PAUSE; 
	    }        
	}

}


