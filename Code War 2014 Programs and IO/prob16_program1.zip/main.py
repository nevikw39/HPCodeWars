import fileinput
from game import Game

for line in fileinput.input():
    game = Game(line)
    game.run()
    print game.result
