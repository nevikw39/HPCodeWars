from collections import defaultdict

class Game(object):
    class Cell(object):
        def __init__(self, game):
            self._game = game

        def __getitem__(self, pos):
            return self._game.cells[pos]

    class Surround(object):
        def __init__(self, game):
            self._game = game

        def __getitem__(self, pos):
            x, y = pos
            surround = 0
            for iy in range(y - 1, y + 2):
                for ix in range(x - 1, x + 2):
                    if self._game.cell[ix, iy]:
                        surround = surround + 1
            return self._game.cell[x, y] and surround - 1 or surround

    def __init__(self, params):
        self._cell = None
        self._surround = None

        self._parse(params)

    def _parse(self, params):
        params = params.split(' ')
        self.width = int(params[0])
        self.height = int(params[1])
        self.data = params[2]
        self.generation = int(params[3])

        self.minX = 0
        self.minY = 0
        self.maxX = self.width
        self.maxY = self.height

        self.steps = 0
        self.cells = defaultdict(
            lambda: False,
            {(i % self.width, i / self.width) : (v == '1') for i, v in enumerate(self.data)}
        )

    @property
    def bound(self):
        minX, minY, maxX, maxY = self.maxX, self.maxY, self.minX, self.minY
        empty = True
        for (ix, iy) in self.cells.keys():
            cell = self.cell[ix, iy]
            if cell:
                minX, minY, maxX, maxY = min(ix, minX), min(iy, minY), max(ix + 1, maxX), max(iy + 1, maxY)
                empty = False
        if empty:
            minX, minY, maxX, maxY = 0, 0, 0, 0
        return {'x': minX, 'y': minY}, {'x': maxX, 'y': maxY}

    @property
    def cell(self):
        if self._cell is None:
            self._cell = self.Cell(self)
        return self._cell

    @property
    def surround(self):
        if self._surround is None:
            self._surround = self.Surround(self)
        return self._surround

    def step(self):
        minX, minY, maxX, maxY = self.maxX, self.maxY, self.minX, self.minY
        cells = {}

        for iy in range(self.minY - 1, self.maxY + 1):
            for ix in range(self.minX - 1, self.maxX + 1):
                s = self.surround[ix, iy]
                c = self.cell[ix, iy]
                n = False

                if c and s < 2: n = False
                elif c and s > 3: n = False
                elif c: n = True
                elif not c and s == 3: n = True

                cells[(ix, iy)] = n

                if n:
                    minX, minY, maxX, maxY = min(ix, minX), min(iy, minY), max(ix + 1, maxX), max(iy + 1, maxY)

        self.minX = minX
        self.maxX = maxX
        self.minY = minY
        self.maxY = maxY
        self.cells = defaultdict(lambda: False, cells)
        self.steps = self.steps + 1

    def run(self):
        for i in range(self.generation):
            self.step()

    @property
    def result(self):
        data = []
        start, end = self.bound
        for iy in range(start['y'], end['y']):
            for ix in range(start['x'], end['x']):
                data.append(self.cell[ix, iy] and '1' or '0')

        result = []
        result.append('%d %d' % (end['x'] - start['x'], end['y'] - start['y']))
        if data:
            result.append(''.join(data))
        return ' '.join(result)
