class Converter(object):
    CODE_VALUE_MAP = {
        '#': 0,
        '%': 1,
        '$': 2,
        '&': 3,
        '\\': 4,
        '~': 5,
        '!': 6,
        '@': -1,
    }

    def __init__(self, params):
        self.params = params

        self._result = None

    @property
    def result(self):
        if self._result is None and len(self.params) > 0:
            self._result = 0
            i = 0
            for v in reversed(self.params):
                if v not in self.CODE_VALUE_MAP:
                    continue
                self._result = self._result + self.CODE_VALUE_MAP[v] * (7 ** i)
                i = i + 1
        return self._result
