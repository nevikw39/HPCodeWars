#!/usr/bin/env python
# -*- coding: utf-8 -*-

class Solver(object):
    class Cell(object):
        def __init__(self, width, height, maze):
            self._width = width
            self._height = height
            self._maze = maze

        def __getitem__(self, pos):
            x, y = pos
            if x < 0 or x >= self._width or y < 0 or y >= self._height:
                return '@'
            return self._maze[y * self._width + x]

        def __setitem__(self, pos, value):
            x, y = pos
            if x < 0 or x >= self._width or y < 0 or y >= self._height:
                return
            self._maze[y * self._width + x] = value

    def __init__(self):
        self._maze = []
        self._width = 0
        self._height = 0
        self._cell = None
        self._start = None
        self._end = None
        self._solved = False
        self._result = None

    def append(self, line):
        line = line.strip()
        if len(line) <= 0:
            return

        self._width = len(line)
        self._height = self._height + 1

        for c in line:
            self._maze.append(c)

    @property
    def width(self):
        return self._width

    @property
    def height(self):
        return self._height

    @property
    def cell(self):
        if self._cell is None:
            self._cell = self.Cell(self._width, self._height, self._maze)
        return self._cell

    @property
    def start(self):
        if self._start is None:
            for y in range(self.height):
                for x in range(self.width):
                    if self.cell[x, y] == '-':
                        self._start = (x, y)
                    if self.cell[x, y] == '*':
                        self._end = (x, y)
        return self._start

    @property
    def end(self):
        if self._end is None:
            for y in range(self.height):
                for x in range(self.width):
                    if self.cell[x, y] == '-':
                        self._start = (x, y)
                    if self.cell[x, y] == '*':
                        self._end = (x, y)
        return self._end

    def _cut(self, end, start):
        current = end
        while current != start:
            cx, cy = current
            up, down = self.cell[cx, cy - 1], self.cell[cx, cy + 1]
            left, right = self.cell[cx - 1, cy], self.cell[cx + 1, cy]

            if up == '↓':
                if current != end:
                    self.cell[cx, cy] = '✗'
                current = (cx, cy - 1)
            elif right == '←':
                if current != end:
                    self.cell[cx, cy] = '✗'
                current = (cx + 1, cy)
            elif down == '↑':
                if current != end:
                    self.cell[cx, cy] = '✗'
                current = (cx, cy + 1)
            elif left == '→':
                if current != end:
                    self.cell[cx, cy] = '✗'
                current = (cx - 1, cy)

    @property
    def result(self):
        self.solve()

        if self._result:
            return self._result

        steps = 0
        current = self.end
        while current != self.start:
            cx, cy = current
            up, down = self.cell[cx, cy - 1], self.cell[cx, cy + 1]
            left, right = self.cell[cx - 1, cy], self.cell[cx + 1, cy]

            # check if there is shortcut first
            if up in ('↑', '→', '←'):
                self._cut((cx, cy), (cx, cy - 1))
                self.cell[cx, cy] = '.'
                current, steps = (cx, cy - 1), steps + 1
            elif right in ('↑', '→', '↓'):
                self._cut((cx, cy), (cx + 1, cy))
                self.cell[cx, cy] = '.'
                current, steps = (cx + 1, cy), steps + 1
            elif down in ('→', '↓', '←'):
                self._cut((cx, cy), (cx, cy + 1))
                self.cell[cx, cy] = '.'
                current, steps = (cx, cy + 1), steps + 1
            elif left in ('↑', '↓', '←'):
                self._cut((cx, cy), (cx - 1, cy))
                self.cell[cx, cy] = '.'
                current, steps = (cx - 1, cy), steps + 1

            # Then check normal path
            if self.cell[cx, cy] != '.':
                if up == '↓':
                    self.cell[cx, cy] = '.'
                    current, steps = (cx, cy - 1), steps + 1
                elif right == '←':
                    self.cell[cx, cy] = '.'
                    current, steps = (cx + 1, cy), steps + 1
                elif down == '↑':
                    self.cell[cx, cy] = '.'
                    current, steps = (cx, cy + 1), steps + 1
                elif left == '→':
                    self.cell[cx, cy] = '.'
                    current, steps = (cx - 1, cy), steps + 1

        # minus one for start point
        steps = steps - 1

        x, y = self.start
        self.cell[x, y] = '-'
        x, y = self.end
        self.cell[x, y] = '*'

        lines = []
        lines.append("Minimum distance: %d steps" % steps)
        for y in range(self.height):
            chars = []
            for x in range(self.width):
                c = self.cell[x, y]
                if c in ('↑', '→', '↓', '←', '✗'):
                    self.cell[x, y] = c = ' '
                chars.append(c)
            lines.append("".join(chars))

        self._result = "\n".join(lines)
        return self._result

    def solve(self):
        if self._solved:
            return

        current = self.start
        while current != self.end:
            cx, cy = current
            up, down = self.cell[cx, cy - 1], self.cell[cx, cy + 1]
            left, right = self.cell[cx - 1, cy], self.cell[cx + 1, cy]

            if up in ('*', ' '):
                self.cell[cx, cy] = '↑'
                current = (cx, cy - 1)
                continue
            elif right in ('*', ' '):
                self.cell[cx, cy] = '→'
                current = (cx + 1, cy)
                continue
            elif down in ('*', ' '):
                self.cell[cx, cy] = '↓'
                current = (cx, cy + 1)
                continue
            elif left in ('*', ' '):
                self.cell[cx, cy] = '←'
                current = (cx - 1, cy)
                continue

            self.cell[cx, cy] = '✗'

            if up == '↓':
                current = (cx, cy - 1)
            elif right == '←':
                current = (cx + 1, cy)
            elif down == '↑':
                current = (cx, cy + 1)
            elif left == '→':
                current = (cx - 1, cy)

        self._solved = True

    def dump(self):
        lines = []
        for y in range(self.height):
            chars = []
            for x in range(self.width):
                chars.append(self.cell[x, y])
            lines.append("".join(chars))

        print "\n".join(lines)
