'''
Created on Nov 2, 2013

@author: evan
'''

import itertools as it


def ConvertListFromStringToInteger(mList):
    for i in range(len(mList)):
        mList[i] = int(mList[i])
        
def Pattern(aList):
    Count = 0
    current = 0
    pattern = []
    for i in aList:
        current +=1
        if i == 0 and Count == 0:
            # no 1 found
            Count = 0
        else:
            if i == 0 and Count != 0:
                pattern.append(Count)
                Count = 0
            else: 
                if i == 1:
                    Count += 1
                    if current == len(aList):
                        pattern.append(Count)
    if len(pattern) == 0:
        pattern.append(0)        
    return pattern
        
def seedMatrix(X,Size):
    numOfSeg = len(X)
    mArray = []
    for Seg in X:
        for i in range(Seg):
            mArray.append(1)
        if len(mArray) < Size:
            mArray.append(0)
            
    if len(mArray) < Size:
        for i in range(Size-len(mArray)):
            mArray.append(0)
    #print (X, ":" ,mArray)
    
    
    return mArray

def RowArrage(mPattern, Max):
    mRow = []
    aRow = []
    for num in mPattern:
        for i in range(num):
            mRow.append(1)
        if num < Max:
            mRow.append(0)
            
    gap = Max - len(mRow)
    if gap != 0:
        for i in range(gap):
            mRow.append(0)
            
    aRow.append(mRow)
    return aRow

def RecInsertSpace(mRow, aRow, gap):
    if gap != 0:
        mRow.pop()
    return mRow
    

#
# Find out all the combination for the specific metrix
#
result = []
def fun(mArray):
    i = 0
    while i < len(mArray) :
        if mArray[i] == 1 and i == 0:
            mArray.insert(i, 0)
            result.append(list(mArray))
            mArray.remove(0)
            i += 1
        else:
            if mArray[i]==1 and mArray[i-1]!=1:
                mArray.insert(i, 0)
                result.append(list(mArray))
                mArray.remove(0)
                i += 1
        i += 1
#------------------------------------------------
#
# Get the data from input.txt
# InputData is a list
#
mFile = open('input3.txt').readlines()

InputData = []

#
# Removing special controlling keys and cut them into different tokens for each line
#
for each_line in mFile:
    InputData.append(each_line.split())

for i in range(len(InputData)):
    ConvertListFromStringToInteger(InputData[i])
    
#
# Get the size
#
ColumnSize = InputData[0][0]
RowSize    = InputData[0][1]

print ('ColumnSize : ', ColumnSize)
print ('RowSize    : ', RowSize)

#
# Generate the Array
#
Array = [[0 for x in range(ColumnSize)] for x in range(RowSize)]

xRay = InputData[1:ColumnSize+1]
yRay = InputData[ColumnSize+1:]
    
print ("The input y-array: ", yRay)
print ("The input x-array: ", xRay)
print ("=====================================")

print("step 1, create the first specific pattern for each input")
ySeedMatrix = []
for pattern in yRay:
    ySeedMatrix.append(seedMatrix(pattern,ColumnSize))

print("step 2 and 3, enumerate all the possible for the row")
print("enumerate all the combinational possibility for all rows")
myDict = {}
eIndex = -1
for each_seed in ySeedMatrix:
    eIndex += 1
    result.clear()
    result.append(each_seed)
    j = 0
    while j < len(result) and (result[j])[-1] ==0:
        newTest = list(result[j])
        if newTest.pop() == 0:
            fun(newTest)
        j += 1
    
    output = []

    for i in result:
        if i not in output:
            output.append(i)
    myDict.update({"ROW"+str(eIndex):output})

# eSum = 1
for key, value in myDict.items():
    print (key,":", value)
#     eSum = eSum*len(value)
    
print("step 4, inspect all the combination")

AllCombin = []
for key in sorted(myDict.keys()):
    AllCombin.append(myDict.get(key))

evan = list(it.product(*AllCombin))

#print("All the combination: ")
#for i in evan:
#    print (i)

print("-------------------------------------------")
Solution = []
for each_combin in evan:
    Found = True
    for i in range(len(xRay)):
        M = [row[i] for row in each_combin]
        ColumnPattern = Pattern(M)
        if xRay[i] != ColumnPattern:
            Found = False
            continue
    if Found == True:
        Solution = each_combin
        print ("Got it!")
        break
        
print ("** Result **")
for i in range(len(Solution)):
    for j in Solution[i]:
        if j == 1:
            print ("@",end="")
        else:
            print (".",end="")
    print ()