import unittest
from ..bs import Converter

class TestBs(unittest.TestCase):
    def setUp(self):
        pass

    def tearDown(self):
        pass

    def testOneDigit(self):
        self.assertEqual(Converter("#").result, 0)
        self.assertEqual(Converter("%").result, 1)
        self.assertEqual(Converter("$").result, 2)
        self.assertEqual(Converter("&").result, 3)
        self.assertEqual(Converter("\\").result, 4)
        self.assertEqual(Converter("~").result, 5)
        self.assertEqual(Converter("!").result, 6)
        self.assertEqual(Converter("@").result, -1)

    def testMultipleDigits(self):
        self.assertEqual(Converter("%&#").result, 70)
        self.assertEqual(Converter("@!\\$~").result, -128)
        self.assertEqual(Converter("!!~").result, 341)
