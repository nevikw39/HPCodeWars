class Converter(object):
    SEQUENCE_LENGTH_MAP = {
        (0x0000, 0x007F): 1,
        (0x0080, 0x07FF): 2,
        (0x0800, 0xFFFF): 3,
        (0x10000, 0x1FFFFF): 4,
    }
    CODE_MASKS_MAP = {
        1: (0b01111111,),
        2: (0b00011111, 0b00111111),
        3: (0b00001111, 0b00111111, 0b00111111),
        4: (0b00000111, 0b00111111, 0b00111111, 0b00111111),
    }
    OFFSETS_MAP = {
        1: (0b00000000,),
        2: (0b11000000, 0b10000000),
        3: (0b11100000, 0b10000000, 0b10000000),
        4: (0b11110000, 0b10000000, 0b10000000, 0b10000000),
    }

    def __init__(self, params):
        self.params = params

        self._value = None
        self._length = None
        self._code = None
        self._result = None

    @property
    def value(self):
        if self._value is None:
            self._value = int(self.params.split('+')[1],
                             base=16)
        return self._value

    @property
    def length(self):
        if self._length is None:
            for (low, high), length in self.SEQUENCE_LENGTH_MAP.iteritems():
                if low <= self.value and self.value <= high:
                    self._length = length
                    break
        return self._length

    @property
    def code(self):
        if self._code is None:
            code = []
            masks = self.CODE_MASKS_MAP[self.length]
            for i, mask in enumerate(reversed(masks)):
                code.insert(0, (self.value >> (i * 6)) & mask)
            self._code = tuple(code)
        return self._code

    @property
    def result(self):
        if self._result is None:
            result = []
            offsets = self.OFFSETS_MAP[self.length]
            for i, c in enumerate(self.code):
                result.append("%X" % (offsets[i] + c,))
            self._result = "".join(result)
        return self._result
